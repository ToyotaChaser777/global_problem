from flask import Flask, render_template,request, redirect

from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///diary.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
#Создание db
db = SQLAlchemy(app)
#Создание таблицы

class Feedback(db.Model):
    #Создание полей
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    email = db.Column(db.String(100), nullable=False)
    text = db.Column(db.Text, nullable=False)    


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/feed', methods=['GET','POST'])
def feed():
    if request.method == 'POST':
        email = request.form['email']
        text = request.form['text']
        feedback = Feedback(email=email, text=text)
        db.session.add(feedback)
        db.session.commit()

        return redirect('/')
    else:    
        return render_template('index.html')

@app.route('/air')
def air():
    return render_template('air.html')

@app.route('/water')
def water():
    return render_template('water.html')

@app.route('/gal', methods=['GET','POST'])
def gal():
    feedback = Feedback.query.all()
    return render_template('gal.html', feedback=feedback)

if __name__ == "__main__":
    app.run(debug=True)